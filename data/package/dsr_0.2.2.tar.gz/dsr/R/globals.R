#' @import utils
utils::globalVariables(c("ratio","difference","se","reference","s_rate","lower","upper"))
utils::globalVariables(c("d", "pop", "wts", "cr_rate", "cr_var","st_rate","st_var","c_rate", "c_lower","c_upper","s_rate","s_lower","s_upper"))
utils::globalVariables(c("nb_lcl","nb_ucl","gam_lcl","gam_ucl","k","followup","std_rate","nb_var","gam_var","var"))
