# dsr
Directly Standardized Rates and Rate Ratios
